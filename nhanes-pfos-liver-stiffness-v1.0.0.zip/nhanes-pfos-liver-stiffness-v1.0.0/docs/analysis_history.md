# Analysis and publication history

- Exploratory later-period and initial cross-period results were inspected before the analysis specification was finalized. No prospective preregistration is claimed.
- The clinical expanded model retained age, sex, race/ethnicity, BMI, diabetes and alcohol category; the base model remains a separate adjustment tier. The covariate set was not selected for this GitHub release.
- Earlier technical corrections, including alcohol routing, VCTE percentage coding, viral marker coding, coefficient inference degrees of freedom and secondary multiplicity families, are recorded in the historical v1.3 specification. Both inference rules are retained.
- The analysis/review/independent_recalc.R script is an independent implementation of the primary models. Prior project language referring to independent review must not be read as completed independent review by a human statistician. Human author, statistical and clinical approval is still required.
- A later presentation-only task split secondary and sensitivity plots into Figures 5 and 6. It added the descriptive coefficient-magnitude calculation using the same 1,323 cases; no regression was refitted.
- 2026-11-16: the public code package retained the historical main and separate recalculation code byte-for-byte and added explicit input-root orchestration. The manifest was expanded from 18 to 20 files to include two previously unlisted SMQ dependencies read by the code. This task performed input hash and syntax checks, not another model fit.

AI assistance included study planning, R/Python code development/debugging, examination of saved outputs, literature organization and drafting/editing. OpenAI Codex was used for this repository preparation and manuscript availability update. The research team must confirm the complete tool history, any additional ChatGPT/other tool use and the final disclosure; no human verification has been fabricated.
