"""Compare regenerated core CSVs with saved aggregates; no model fitting or value replacement."""
from pathlib import Path
import csv,math,json
R=Path(__file__).resolve().parents[1]
# These are presentation assemblies rather than direct main-analysis output files.
exclude={'sensitivity_with_probe.csv'}
results=[]
for ref in sorted((R/'data').glob('*.csv')):
 if ref.name in exclude:continue
 actual=R/'analysis/outputs'/ref.name
 if not actual.exists():raise SystemExit('Missing regenerated output: '+str(actual))
 a=list(csv.DictReader(ref.open(encoding='utf-8-sig')));b=list(csv.DictReader(actual.open(encoding='utf-8-sig')))
 if len(a)!=len(b):raise SystemExit('Row count differs: '+ref.name)
 for i,(x,y) in enumerate(zip(a,b),1):
  if x.keys()!=y.keys():raise SystemExit('Columns differ: '+ref.name)
  for k in x:
   if x[k]==y[k]:continue
   try:ok=math.isclose(float(x[k]),float(y[k]),rel_tol=1e-9,abs_tol=1e-11)
   except (ValueError,TypeError):ok=False
   if not ok:raise SystemExit(f'Numerical/text difference: {ref.name}, row {i}, {k}: {x[k]} vs {y[k]}')
 results.append({'file':ref.name,'rows':len(a),'status':'matched'})
print(json.dumps({'comparisons':results,'meaning':'Numerical agreement only, not independent scientific validation'},indent=2))
