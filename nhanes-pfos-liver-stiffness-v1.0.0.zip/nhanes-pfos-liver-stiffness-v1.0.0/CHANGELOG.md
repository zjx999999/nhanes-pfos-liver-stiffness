# Version 1.0.0

Initial public reproducibility snapshot, 2026-11-16. Includes unchanged historical R model/recalculation code, frozen aggregate outputs, a complete 20-file CDC input manifest and source checksums, Python data-verification helpers, and final presentation code. No participant-level data or manuscript is included. No new models or altered statistical estimates were produced while assembling this release.
