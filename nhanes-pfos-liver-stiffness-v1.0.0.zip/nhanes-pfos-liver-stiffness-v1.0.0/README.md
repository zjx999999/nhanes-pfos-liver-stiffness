# NHANES PFOS and liver stiffness across two survey periods

Reproducibility materials for **Cross-Period Comparison of Serum PFOS and Liver Stiffness Associations in NHANES 2017–2018 and 2021–2023**.

Repository: https://github.com/zjx999999/nhanes-pfos-liver-stiffness

## Scope

The study estimates the cross-sectional association between serum total PFOS per doubling and continuous log liver stiffness separately in NHANES 2017–2018 and 2021–2023. Base and clinically extended models are compared in the same complete-case samples, alongside available-case estimates and a period coefficient difference. CAP and other PFAS are secondary outcomes/exposures. The clinical adjustment set and frozen estimates have not been changed for this repository.

This is a research code archive accompanying an author-review manuscript, not a statement of peer review, publication, causal identification or completion of an independent human statistical review.

## Contents

- `analysis/scripts/main_analysis.R`: historical full analysis, unchanged.
- `analysis/review/independent_recalc.R`: separate minimal recalculation code, unchanged; the word independent describes code implementation, not certification by a human reviewer.
- `analysis/reproducibility/data_manifest.csv`: official CDC URLs, byte counts and SHA-256 for all 20 files the code reads.
- `analysis/reproducibility/sessionInfo.txt`: recorded R environment, including R 4.5.3, survey 4.5 and haven 2.5.5.
- `data/`: frozen aggregate outputs and descriptive formula records; no participant-level records.
- `scripts/plot_figures.py` and `figures/`: presentation code and six main figures plus the supplementary roadmap, rebuilt from saved outputs without fitting models.
- `docs/`: finalized analysis specification and honest analysis-history/provenance notes.
- `SHA256SUMS.txt`: integrity checks for the uploaded files, excluding the checksum file itself.

## Start

See [REPRODUCIBILITY.md](REPRODUCIBILITY.md). The data retrieval and checksum tools use Python standard-library modules. The analysis uses R; graphical reconstruction uses Python/Matplotlib. Download inputs directly from CDC; do not upload XPT files here.

```sh
python3 scripts/verify_payload.py
python3 scripts/fetch_data.py --verify-only  # after inputs have been obtained
bash run_reproduction.sh                    # explicitly runs the fixed analysis
```

The public snapshot was prepared on 2026-11-16. Repository preparation checked source preservation, syntax and existing input hashes; it did **not** execute another NHANES model fit. Previous project reproduction records are distinct from independent human review. Running the shell entry point is an explicit reproduction of the frozen analysis, not a new model-development workflow.

## Important interpretation

The finalized plan followed inspection of exploratory outputs; this is not prospective preregistration. Primary coefficient inference uses 15 domain design degrees of freedom, with model-residual-df sensitivity. Complete-case selection and alcohol missingness remain limitations. Period differences do not test equivalence. LSM is not histologic confirmation of fibrosis. A 52.7% reduction in an earlier-period coefficient magnitude is descriptive, not causal mediation or a proportion explained by a particular covariate.

The earlier survey sample overlaps the public data analyzed by Samala et al. (2024), [doi:10.1093/toxsci/kfae106](https://doi.org/10.1093/toxsci/kfae106). This project adds the later public survey sample and a harmonized, explicitly weighted comparison; its unweighted earlier-period approximation is not an exact reproduction of that paper.

## Data, manuscript and authorship

Original data and documentation are provided by [CDC/NCHS NHANES](https://wwwn.cdc.gov/nchs/nhanes/). No participant-level XPT files, identifiable data, credentials, private author declarations, full manuscript or internal reviewer investigations are distributed here. GitHub account ownership is not a claim of scientific authorship or institutional affiliation. Authors and institutional declarations remain to be confirmed by the research team.

No third-party articles are redistributed. No software license or creator metadata has been invented on behalf of the authors; final licensing and citation metadata require the rights holders' decision. A GitHub release/tag provides a versioned URL, not a DOI or guaranteed permanent archive.
